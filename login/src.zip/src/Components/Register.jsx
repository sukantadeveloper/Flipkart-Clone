import React from 'react'
import { Login } from './Login'
import { Signup } from './SignUp'

const Register = () => {
  return (
    <div>
     
        <Login/>
        
    </div>
  )
}

export default Register